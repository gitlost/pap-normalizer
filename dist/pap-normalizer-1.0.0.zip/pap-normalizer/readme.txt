=== PAP Normalizer ===
Contributors: gitlost
Tags: Unicode, Normalization, Normalize, Normalizer, UTF-8, NFC
Requires at least: 3.9.13
Tested up to: 4.6.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Patch-as-plugin that adds the Normalizer class to WP.

== Description ==

Adds the Symfony Normalizer polyfill if the `Intl` extension is not installed.
